# SPDX-FileCopyrightText: 2023-present Alvaro Leiva Geisse <aleivag@gmail.com>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == "__main__":
    from dumas.cli import dumas

    sys.exit(dumas())
